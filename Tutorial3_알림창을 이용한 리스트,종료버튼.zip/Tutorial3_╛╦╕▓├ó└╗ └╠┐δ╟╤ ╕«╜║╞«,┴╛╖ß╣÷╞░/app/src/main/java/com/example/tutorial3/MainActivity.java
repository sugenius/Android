package com.example.tutorial3;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String[] items={"망고 쥬스", "토마토 쥬스","포도 쥬스"}; //리스트에 들어갈 내용

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button listButton = (Button) findViewById(R.id.listButton); //UI로 부터 버튼에 대한 정보를 받아와 그것을 버튼 객체로 만듦 이 객체는 listButton으로 써 저장이 됨.
        listButton.setOnClickListener(new View.OnClickListener() { //버튼을 눌렀을 때 이벤트 실행
            @Override
            public void onClick(View v) { //버튼을 클릭했을 때에 대한 함수 처리 정의
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("리스트"); //팝업창 제목
                builder.setItems(items, new DialogInterface.OnClickListener() {//팝업창 리스트 내용
                    @Override //리시트 안에 있던 내용을 클릭했을 때에 대한 이벤트 처리
                    public void onClick(DialogInterface dialoginterface, int i) { //특정한 정보를 클릭했을 때 이벤트 처리
                        Toast.makeText(getApplicationContext(), items[i], Toast.LENGTH_SHORT).show(); //자신이 지금 클릭한 내용을 토스트로써 잠시 띄우기
                        //인덱스를 받아 해당 인덱스에 대한 내용 띄움
                    }
                });
                AlertDialog alertDialog = builder.create(); //알림창 객체 생성
                alertDialog.show(); //알림창 띄우기

            }
        });

        //EXIT 버튼
        Button exitButton = (Button) findViewById(R.id.exitButton); //ui에서 id를 받아온 후 button 객체 생성
        exitButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ //해당 버튼을 눌렀을 때 onClick 함수 실행됨
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this); //AlertDialog.Builder를 만들어 builder 할당 , 해당 내용은 MainActivity에 종속되게 함
                builder.setMessage("정말로 종료하시겠습니까?"); //해당 builder 메시지 출력
                builder.setTitle("종료 알림창") //알림 제목 설정
                        .setCancelable(false) //사용자가 임의로 종료하지 못하게 함
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() { //yes 버튼
                            @Override
                            public void onClick(DialogInterface dialog, int i){
                                finish(); //인위적인 프로그램 종료
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() { //no 버튼
                            @Override
                            public void onClick(DialogInterface dialog, int i) {
                                dialog.cancel(); //dialog 창 종료되도록 함
                            }
                        });
                AlertDialog alert= builder.create();
                alert.setTitle("종료 알림창");
                alert.show();
            }
        });

    }
}
